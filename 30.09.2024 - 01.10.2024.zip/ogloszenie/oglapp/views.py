from django.shortcuts import render, redirect
from .models import *
from django.forms import modelform_factory
# Create your views here.

def index(request):
    ogloszenia =Ogloszenia.objects.all()
    return render(request,'index.html',{'ogloszenia':ogloszenia})


def tresc(request,id):
    pobieranie = Ogloszenia.objects.get(pk=id)
    if request.method == 'POST':
        pobieranie.delete()
        return redirect('/')
    return render(request, 'tresc.html',{'pobieranie':pobieranie})

def index2(request):
    uzytkownik = Uzytkownik.objects.all()
    return render(request,'uzytkownik.html', {'uzytkownik':uzytkownik})

def ksiega(request):
    ksiazka = Ogloszenia.objects.filter(kategoria=1)
    return render(request, 'ksiazka.html', {'ksiazka':ksiazka})

def new(request):
    news = modelform_factory(Uzytkownik, exclude=[])
    form = news()

    if request.method == 'POST':
        form = news(request.POST)
        if form.is_valid():
            form.save()
            return redirect('uzytkownik')
    else:
        form = news()

    return render(request, "new.html", {'form': form})

def nowe(request):
    nowes = modelform_factory(Ogloszenia, exclude=[])
    forms = nowes()

    if request.method == 'POST':
        forms = nowes(request.POST)
        if forms.is_valid():
            forms.save()
            return redirect('/')
    else:
        forms = nowes()

    return render(request, 'noweogloszenie.html',{'forms' : forms})