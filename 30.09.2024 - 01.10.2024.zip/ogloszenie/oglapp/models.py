from django.db import models

# Create your models here.
class Uzytkownik(models.Model):
    imie = models.CharField(max_length=200)
    nazwisko = models.CharField(max_length=200)
    telefon = models.PositiveIntegerField(max_length=100)
    email = models.EmailField(max_length=500)

    def __str__(self):
        return f"{self.imie}, {self.nazwisko}"

class Ogloszenia(models.Model):
    kategoria = models.SmallIntegerField(max_length=100)
    podkategoria = models.SmallIntegerField(max_length=100)
    tytul = models.CharField(max_length=100)
    tresc = models.TextField(max_length= 500)
    uzytkownik_id = models.ForeignKey(Uzytkownik,on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.kategoria}, {self.podkategoria}, {self.tytul}, {self.tresc}, {self.uzytkownik_id}"