from django.db import models

# Create your models here.

class Rodzina(models.Model):
    nazwa = models.CharField(max_length=200)

    def __str__(self):
        return f"{self.nazwa}"

class Potrawy(models.Model):
    nazwa = models.CharField(max_length=200)

    def __str__(self):
        return f"{self.nazwa}"

class Grzyby(models.Model):
    nazwa = models.CharField(max_length=200)
    potoczna = models.CharField(max_length=200)
    jadalny = models.CharField(max_length=200)
    miesiac_zbierania = models.CharField(max_length=200)
    rodzina_id = models.ForeignKey(Rodzina,on_delete=models.CASCADE)
    potrawy_id = models.ForeignKey(Potrawy,on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.nazwa} nazwa potoczna - {self.potoczna}, należy o rodziny {self.rodzina_id.nazwa}"


