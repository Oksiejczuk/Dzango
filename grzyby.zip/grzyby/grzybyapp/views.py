from django.shortcuts import render
from .models import Grzyby
# Create your views here.
def dane(request):
    grzyb = Grzyby.objects.all()
    return render(request,"index.html",{"grzybek":grzyb})