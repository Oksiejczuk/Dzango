from django import forms
from django.forms import ModelForm
from .models import Zgloszenia


class ZglForm(ModelForm):
    class Meta:
        model = Zgloszenia
        fields = ["adres", "pilne", "czas_zgloszenia", "ratownicy_id", "dyspozytorzy_id"]

