from django.db import models

# Create your models here.
class Dyspozytorzy(models.Model):
    imie = models.CharField(max_length=100)
    nazwisko = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.imie},{self.nazwisko}"

class Ratownicy(models.Model):
    numerKaretki = models.SmallIntegerField(max_length=100)
    ratownik1 = models.CharField(max_length=100)
    ratownik2 = models.CharField(max_length=100)
    ratownik3 = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.numerKaretki},{self.ratownik1},{self.ratownik2},{self.ratownik3}"

class Zgloszenia(models.Model):
    adres = models.CharField(max_length=1000)
    pilne = models.BooleanField()
    czas_zgloszenia = models.TimeField()
    ratownicy_id = models.ForeignKey(Ratownicy,on_delete=models.CASCADE)
    dyspozytorzy_id = models.ForeignKey(Dyspozytorzy,on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.adres},{self.pilne},{self.czas_zgloszenia},{self.ratownicy_id},{self.dyspozytorzy_id}"