from django.shortcuts import render,redirect
from .models import *
from .form import *
from django.forms import modelform_factory
# Create your views here.

def index (request):
    zgloszenie = Zgloszenia.objects.all()
    if request.method == 'POST':
        form = ZglForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    else:
        form = ZglForm()
    return render(request, "pogotowie.html",{"zgloszenie": zgloszenie, "form":form})
