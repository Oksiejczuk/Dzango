from django.shortcuts import render
from .models import *
# Create your views here.

def index(request):
    ogloszenia =Ogloszenia.objects.all()
    return render(request,'index.html',{'ogloszenia':ogloszenia})


def tresc(request,id):
    pobieranie = Ogloszenia.objects.get(pk=id)
    return render(request, 'tresc.html',{'pobieranie':pobieranie})

def index2(request):
    uzytkownik = Uzytkownik.objects.all()
    return render(request,'uzytkownik.html', {'uzytkownik':uzytkownik})

def ksiega(request):
    ksiazka = Ogloszenia.objects.filter(kategoria=1)
    return render(request, 'ksiazka.html', {'ksiazka':ksiazka})