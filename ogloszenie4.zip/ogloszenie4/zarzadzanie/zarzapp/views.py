from django.shortcuts import render,HttpResponse
from django.contrib.auth.decorators import login_required


# Create your views here.
def welcome(request):
    return render(request,"welcome.html")

@login_required
def zaloguj(request):
    return HttpResponse("To jest strona dostępna po zalogowaniu")

def inna(request):
    return HttpResponse("Inna strona")
