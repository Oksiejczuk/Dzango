from django.shortcuts import render, redirect
from .models import *
from django.forms import modelform_factory
from .forms import OglForm,UzytkFrom
from django.contrib.auth.decorators import login_required
# Create your views here.

def index(request):
    ogloszenia =Ogloszenia.objects.all()
    return render(request,'index.html',{'ogloszenia':ogloszenia})


def tresc(request,id):
    pobieranie = Ogloszenia.objects.get(pk=id)
    if request.method == 'POST':
        pobieranie.delete()
        return redirect('/')
    return render(request, 'tresc.html',{'pobieranie':pobieranie})

def index2(request):
    uzytkownik = Uzytkownik.objects.all()
    return render(request,'uzytkownik.html', {'uzytkownik':uzytkownik})

def ksiega(request):
    ksiazka = Ogloszenia.objects.filter(kategoria=1)
    return render(request, 'ksiazka.html', {'ksiazka':ksiazka})
@login_required
def new(request):

    if request.method == 'POST':
        form = UzytkFrom(request.POST)
        if form.is_valid():
            form.save()
            return redirect('uzytkownik')
    else:
        form = UzytkFrom()

    return render(request, "new.html", {'form': form})

@login_required
def nowe(request):

    if request.method == 'POST':
        forms = OglForm(request.POST)
        if forms.is_valid():
            forms.save()
            return redirect('/')
    else:
        forms = OglForm()

    return render(request, 'noweogloszenie.html',{'forms' : forms})

